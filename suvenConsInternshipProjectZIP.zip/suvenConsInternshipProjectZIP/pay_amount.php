<?php
 session_start();
?>

<html>

<head>
<link rel="stylesheet" type="text/css" href="over_style.css">
</head>

<body>
<div class="header">
<h1><b><font size="24">WELCOME TO MYNTRA</font></b></h1>
</div>

<div id="nav">
<br><br>


<div class="main">
<ul>
  <li> <a href="user_reg.html" target="blank"> LOGIN </a> </li><br>
  
  </ul>
</div>



</div>
</body>
</html>